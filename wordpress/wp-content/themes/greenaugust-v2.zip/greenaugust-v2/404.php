<?php get_header(); ?>
<?php get_template_part('templates/template', 'header'); ?>

<div class="heading msg-404">
  Looks like the page you were looking for doesn't exist! Sorry about that.
</div>

<?php get_template_part('templates/template', 'footer'); ?>
<?php get_footer(); ?>
