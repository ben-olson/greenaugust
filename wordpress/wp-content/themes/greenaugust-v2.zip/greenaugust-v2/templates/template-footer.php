<div class="[ footer ] [ flex ]">

<p>Return to <a class="[ link ]" href="/">home</a>.</p>
<p>Return to <a class="[ link ]" href="#top">top</a>.</p>

</div>
