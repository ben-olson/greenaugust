<article class="[ post ] [ flow:wide ]">

  <h2 class="[ font-size:s3 upper font:light msg msg__redirect ]">
    Looks like the article you are looking for is not published on this site!
  </h2>
  <p>Follow the link below to see the external article in its full glory:</p>
  <a class="[ link ]" href="<?php echo get_field('published-article-url', get_the_id()); ?>"><?php echo get_field('published-article-url', get_the_id()); ?></a>

</article>
